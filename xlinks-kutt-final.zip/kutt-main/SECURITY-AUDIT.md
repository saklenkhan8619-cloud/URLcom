# Security audit notes

## Changed in this pass
- Rate limiting is now ON by default (`ENABLE_RATE_LIMIT=true`); added limits to link creation, protected-link password forms, reports, and Basic-auth access to protected short links.
- Production start is refused if `JWT_SECRET` is shorter than 32 characters or a known placeholder.
- JWTs are signed and verified with HS256 only; login timing no longer reveals whether an email exists.
- Link targets and domain homepages with `javascript:`, `data:`, `vbscript:`, `file:`, `blob:`, `about:` schemes are rejected (also blocked at redirect time for older stored links).
- Content-Security-Policy, Referrer-Policy and the other Helmet headers are enabled. Scripts still need `'unsafe-inline'`/`'unsafe-eval'` because htmx and inline handlers are used in the templates.
- Request bodies limited to 100kb.
- `.dockerignore` now keeps `.env`, DB files, keys and logs out of the image.

## Not done / needs you
- Dependencies were NOT audited or updated (npm registry was unreachable from the audit sandbox). Run `npm audit` and `npm audit fix`, then test.
- Git history was NOT checked (the zip has no `.git`). Run `gitleaks detect` or `trufflehog git file://.` in your repo.
- `TRUST_PROXY` defaults to true. Keep it true only behind a reverse proxy/CDN; otherwise set `TRUST_PROXY=false` or clients can fake their IP and bypass rate limits.
- API keys are stored in plaintext in the DB (Kutt shows them again in Settings). Protect DB access/backups.
- JWTs cannot be revoked before expiry (7 days); changing `JWT_SECRET` logs everyone out.
- The Docker image runs as root; consider `USER node` after fixing volume permissions.
- Create the admin account immediately after first deploy: `/create-admin` is open until the first user exists.
- Passwords are hashed with bcrypt (cost 12): already fine.
