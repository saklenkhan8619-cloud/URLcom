#!/usr/bin/env node
// Dependency-free load test. Usage:
//   node tools/loadtest.js http://localhost:3000 [shortAddress] [concurrency] [seconds]
// Hits: /api/health, / (homepage), /<shortAddress> (redirect, not followed), /nonexistent404 (cache miss)
const http = require("node:http");
const https = require("node:https");

const base = new URL(process.argv[2] || "http://localhost:3000");
const address = process.argv[3] || "";
const concurrency = parseInt(process.argv[4]) || 100;
const seconds = parseInt(process.argv[5]) || 15;
const lib = base.protocol === "https:" ? https : http;
const agent = new lib.Agent({ keepAlive: true, maxSockets: concurrency });

const paths = ["/api/health", "/", "/nonexistent-" + Date.now()];
if (address) paths.push("/" + address, "/" + address, "/" + address); // weight redirects higher

const stats = { total: 0, errors: 0, status: {}, lat: [] };
const end = Date.now() + seconds * 1000;

function hit() {
  return new Promise(resolve => {
    const path = paths[Math.floor(Math.random() * paths.length)];
    const t = process.hrtime.bigint();
    const req = lib.request({ host: base.hostname, port: base.port, path, method: "GET", agent, timeout: 10000 }, res => {
      res.resume();
      res.on("end", () => {
        stats.total++;
        stats.status[res.statusCode] = (stats.status[res.statusCode] || 0) + 1;
        stats.lat.push(Number(process.hrtime.bigint() - t) / 1e6);
        resolve();
      });
    });
    req.on("timeout", () => req.destroy(new Error("timeout")));
    req.on("error", () => { stats.errors++; resolve(); });
    req.end();
  });
}

async function worker() {
  while (Date.now() < end) await hit();
}

(async () => {
  console.log(`Load test ${base.origin} concurrency=${concurrency} duration=${seconds}s paths=${paths.length}`);
  await Promise.all(Array.from({ length: concurrency }, worker));
  stats.lat.sort((a, b) => a - b);
  const p = q => stats.lat[Math.min(stats.lat.length - 1, Math.floor(stats.lat.length * q))]?.toFixed(1);
  console.log({
    requests: stats.total, rps: Math.round(stats.total / seconds), connectionErrors: stats.errors,
    status: stats.status, p50_ms: p(0.5), p95_ms: p(0.95), p99_ms: p(0.99), max_ms: stats.lat.at(-1)?.toFixed(1),
  });
  // 429 is expected: the rate limiter is working. 5xx or connection errors mean trouble.
  const bad = Object.entries(stats.status).filter(([s]) => +s >= 500).reduce((a, [, n]) => a + n, 0) + stats.errors;
  process.exit(bad ? 1 : 0);
})();
