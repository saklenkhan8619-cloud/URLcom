// Small dependency-free in-memory TTL cache with a size cap.
// Used for hot lookups (short link redirects) when Redis is not enabled.
// Note: each process has its own cache. If you run several instances, use Redis instead.

class MemoryCache {
  constructor({ ttlMs = 60 * 1000, maxEntries = 5000 } = {}) {
    this.ttlMs = ttlMs;
    this.maxEntries = maxEntries;
    this.map = new Map();
  }

  get(key) {
    const entry = this.map.get(key);
    if (!entry) return undefined;
    if (entry.expires <= Date.now()) {
      this.map.delete(key);
      return undefined;
    }
    return entry.value;
  }

  set(key, value) {
    // refresh insertion order so the oldest entry is always the first key
    this.map.delete(key);
    this.map.set(key, { value, expires: Date.now() + this.ttlMs });
    while (this.map.size > this.maxEntries) {
      this.map.delete(this.map.keys().next().value);
    }
  }

  del(key) {
    this.map.delete(key);
  }

  get size() {
    return this.map.size;
  }
}

module.exports = MemoryCache;
